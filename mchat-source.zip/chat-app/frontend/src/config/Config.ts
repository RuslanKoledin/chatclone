// В продакшене (статика раздаётся Spring Boot) — пустая строка, запросы идут на тот же хост
// В разработке — указать через .env: REACT_APP_API_URL=http://localhost:8080
export const BASE_API_URL = process.env.REACT_APP_API_URL || "";
export const WS_URL = process.env.REACT_APP_WS_URL || "/ws";
export const TOKEN = 'token';
export const TOKEN_EXPIRES_AT = 'token_expires_at';
export const SESSION_DURATION_MS = 8 * 60 * 60 * 1000;
